# QR_Ticketing
Automatic Genration and retirieval of Tickets using QR code .


UNDER DEVELOPMENT