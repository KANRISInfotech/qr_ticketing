function useqrdata(data) {
    alert(data);
}