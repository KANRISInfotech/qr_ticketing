$(document).ready(function() {
    $("#book_now").click(function(e) {
        e.preventDefault();
        bookticket();
    })
    $("#refby").select2();
    $("#no_tick").select2();
})

function generate_qr(data) {
    $("#qr").remove();
    var qr = '<img id="qr" style="display:none;" src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' + data + '">';
    $("#qr_container").append(qr);
    $("#qr").fadeIn();
}

function bookticket() {
    var name = $('[name="name"]').val();
    var age = $('[name="age"]').val();
    var mail = $('[name="mail"]').val();
    var number = $('[name="number"]').val();
    var ref_det = $('[name="ref_det"]').val();
    var no_tick = $("#no_tick").val();
    var refby = $("#refby").val();
    var error = false;
    var regexmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,5})+$/;
    if (!regexmail.test(mail)) {
        error = true;
        $('[name="mail"]').css("border-color", "#D8000C");
    } else {
        $('[name="mail"]').css("border-color", "#666");
    }
    if (number.length !== 10) {
        error = true;
        $('[name="number"]').css("border-color", "#D8000C");
    } else {
        $('[name="number"]').css("border-color", "#666");
    }
    if (name.length == 0) {
        error = true;
        $('[name="name"]').css("border-color", "#D8000C");
    } else {
        $('[name="name"]').css("border-color", "#666");
    }
    if (age.length == 0) {
        error = true;
        $('[name="age"]').css("border-color", "#D8000C");
        errorline = "15"
    } else {
        $('[name="age"]').css("border-color", "#666");
    }
    if (ref_det.length == 0) {
        error = true;
        $('[name="ref_det"]').css("border-color", "#D8000C");
    } else {
        $('[name="ref_det"]').css("border-color", "#666");
    }
    if (no_tick == "" || refby == "") {
        error = true;
    }
    if (error == true) {
        alert("Please fill all the fields");
    } else {
        $.ajax({
            url: "bookticket.php",
            type: "GET",
            contenttype: "JSON",
            data: { name: name, age: age, mail: mail, number: number, ref_det: ref_det, no_tick: no_tick, refby: refby },
            timeout: 10000,
            success: function() {

            },
            error: function(x, t, m) {
                if (t === "timeout") {
                    alert("got timeout");
                } else {
                    alert(t);
                }
            }
        })
    }
}