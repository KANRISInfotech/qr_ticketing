# QR_Ticketing
Automatic Genration and retirieval of Tickets using QR code .

Using Instascan API : https://github.com/schmich/instascan

# UNDER DEVELOPMENT